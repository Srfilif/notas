<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Componente - Sidebar</title>

    <!-- Enlazar Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Incluir SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://kit.fontawesome.com/198d3df6d4.js" crossorigin="anonymous"></script>

    <!-- Personalización de la clase active -->
    <style>
        .nav-link.active {
            background-color: #0d6efd !important;
            /* Azul de Bootstrap */
            color: white !important;
            /* Cambia el color de la fuente a blanco */
        }

        /* Asegurarse de que los enlaces no activos tengan color blanco */
        .nav-link {
            color: #fff !important;
            /* Asegura que el texto sea blanco */
        }
    </style>
</head>

<body>
    <div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark" style="width: 280px; height: 100vh; position: fixed;">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap" />
            </svg>
            <span class="fs-4">Sistema de Notas</span>
        </a>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="nav-item">
                <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" aria-current="page">
                    <i class="fa-solid fa-house"></i>
                    Inicio
                </a>
            </li>

            <li>
                <a href="academico.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'academico.php' ? 'active' : ''; ?> text-white">
                    <i class="fa-solid fa-gauge"></i>
                    Estado académico
                </a>
            </li>

            <li>
                <a href="notas.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'notas.php' ? 'active' : ''; ?> text-white">
                    <i class="fa-solid fa-message"></i>
                    Faltas y Anotaciones
                </a>
            </li>
            <hr>

            <li>
                <a href="instances.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'instances.php' ? 'active' : ''; ?> text-white" aria-current="page">
                <i class="fa-regular fa-calendar-check"></i>                    Categoría de Notas
                </a>
            </li>
            <li>
                <a href="seguimiento.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'seguimiento.php' ? 'active' : ''; ?> text-white">
                <i class="fa-solid fa-users"></i>                    Seguimiento
                </a>
            </li>
            <li>
                <a href="usuarios.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'usuarios.php' ? 'active' : ''; ?> text-white">
                <i class="fa-solid fa-users"></i>                    Usuarios
                </a>
            </li>
        </ul>
        <hr>
        <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="https://via.placeholder.com/32" alt="Usuario" width="32" height="32" class="rounded-circle me-2">
                <strong><?= $_SESSION['usuario_nombre'] ?? 'Usuario'; ?></strong>
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                <li><a class="dropdown-item" href="configuracion.php">Configuración</a></li>
                <li><a class="dropdown-item" href="perfil.php">Perfil</a></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="logout.php">Cerrar sesión</a></li>
            </ul>
        </div>
    </div>
</body>

</html>