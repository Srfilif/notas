<?php
include 'database.php';

// registro.php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $rol = $_POST['rol']; // El rol será 'estudiante' o 'profesor'

    $query = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $nombre, $email, $password, $rol);

    if ($stmt->execute()) {
        echo "Registro exitoso. Ahora puedes iniciar sesión.";
    } else {
        echo "Error al registrar. Intenta nuevamente.";
    }
}

?>

<form action="registro.php" method="POST">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required><br>
    
    <label for="email">Correo electrónico:</label>
    <input type="email" name="email" required><br>
    
    <label for="password">Contraseña:</label>
    <input type="password" name="password" required><br>
    
    <label for="rol">Rol:</label>
    <select name="rol">
        <option value="estudiante">Estudiante</option>
        <option value="profesor">Profesor</option>
    </select><br>
    
    <input type="submit" value="Registrar">
</form>

