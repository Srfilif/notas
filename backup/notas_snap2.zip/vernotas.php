<?php
session_start();
include 'database.php';

// Verificar si el usuario está logueado y es un estudiante
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: login.php");
    exit;
}

// Obtener el ID de la materia seleccionada (si lo hay)
$materia_id = isset($_GET['materia_id']) ? intval($_GET['materia_id']) : null;

// Obtener las materias del estudiante
$usuario_id = $_SESSION['usuario_id'];
$materias = $conn->query("SELECT DISTINCT m.id, m.nombre
                          FROM materias m
                          JOIN notas n ON m.id = n.materia_id
                          WHERE n.estudiante_id = $usuario_id");

// Filtrar las notas y categorías según la materia seleccionada
$notas_query = "SELECT n.nota, m.nombre AS materia, c.nombre AS categoria, m.id AS materia_id
                FROM notas n
                JOIN materias m ON n.materia_id = m.id
                JOIN categorias_notas c ON n.categoria_id = c.id
                WHERE n.estudiante_id = $usuario_id";

$categorias_query = "SELECT c.nombre AS categoria, m.nombre AS materia, m.id AS materia_id
                     FROM categorias_notas c
                     JOIN materias m ON c.materia_id = m.id";

if ($materia_id) {
    $notas_query .= " AND m.id = $materia_id";
    $categorias_query .= " WHERE m.id = $materia_id";
}

$notas = $conn->query($notas_query);
$categorias = $conn->query($categorias_query);

// Agrupar notas y categorías por materia
$materias_notas = [];
while ($nota = $notas->fetch_assoc()) {
    $materias_notas[$nota['materia']][] = $nota;
}

$materias_categorias = [];
while ($categoria = $categorias->fetch_assoc()) {
    $materias_categorias[$categoria['materia']][] = $categoria['categoria'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Notas</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <div class="container">
        <h1>Mis Notas</h1>

        <!-- Formulario para seleccionar la materia -->
        <form method="GET" action="">
            <label for="materia">Seleccionar Materia:</label>
            <select name="materia_id" id="materia" onchange="this.form.submit()">
                <option value="">-- Ver Todas --</option>
                <?php while ($materia = $materias->fetch_assoc()): ?>
                    <option value="<?php echo $materia['id']; ?>" <?php echo $materia_id == $materia['id'] ? 'selected' : ''; ?>>
                        <?php echo $materia['nombre']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>

        <!-- Mostrar las tablas de notas -->
        <?php foreach ($materias_notas as $materia_nombre => $notas_materia): ?>
            <h2>Materia: <?php echo $materia_nombre; ?></h2>
            <table border="1">
                <thead>
                    <tr>
                        <th colspan="<?php echo count($materias_categorias[$materia_nombre]); ?>"><?php echo $materia_nombre; ?></th>
                    </tr>
                    <tr>
                        <?php foreach ($materias_categorias[$materia_nombre] as $categoria): ?>
                            <th><?php echo $categoria; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php foreach ($materias_categorias[$materia_nombre] as $categoria): ?>
                            <td>
                                <?php
                                $nota_en_categoria = '';
                                foreach ($notas_materia as $nota) {
                                    if ($nota['categoria'] === $categoria) {
                                        $nota_en_categoria = $nota['nota'];
                                        break;
                                    }
                                }
                                echo $nota_en_categoria;
                                ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                </tbody>
            </table>
        <?php endforeach; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
