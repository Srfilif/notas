<?php
session_start();
include 'database.php';

// Verificar si el usuario está logueado y es un estudiante
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: login.php");
    exit;
}

// Obtener las materias del estudiante
$usuario_id = $_SESSION['usuario_id'];
$materias = $conn->query("SELECT DISTINCT m.id, m.nombre
                          FROM materias m
                          JOIN notas n ON m.id = n.materia_id
                          WHERE n.estudiante_id = $usuario_id");

// Obtener las notas basadas en la selección del estudiante
$materia_id = isset($_GET['materia_id']) ? $_GET['materia_id'] : null;
$notas = [];

if ($materia_id) {
    // Si se selecciona una materia, obtener solo las notas de esa materia
    $notas = $conn->query("SELECT n.nota, m.nombre AS materia, c.nombre AS categoria
                           FROM notas n
                           JOIN materias m ON n.materia_id = m.id
                           JOIN categorias_notas c ON n.categoria_id = c.id
                           WHERE n.estudiante_id = $usuario_id AND n.materia_id = $materia_id");
} else {
    // Si no se selecciona ninguna materia, obtener todas las notas
    $notas = $conn->query("SELECT n.nota, m.nombre AS materia, c.nombre AS categoria
                           FROM notas n
                           JOIN materias m ON n.materia_id = m.id
                           JOIN categorias_notas c ON n.categoria_id = c.id
                           WHERE n.estudiante_id = $usuario_id");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Notas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Mis Notas</h1>

        <!-- Formulario para seleccionar la materia o ver todas -->
        <form method="GET" action="">
            <label for="materia">Seleccionar Materia:</label>
            <select name="materia_id" id="materia" onchange="this.form.submit()">
                <option value="">-- Ver Todas --</option>
                <?php while ($materia = $materias->fetch_assoc()): ?>
                    <option value="<?php echo $materia['id']; ?>" <?php echo $materia_id == $materia['id'] ? 'selected' : ''; ?>>
                        <?php echo $materia['nombre']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>

        <!-- Mostrar las notas en una tabla -->
        <table border="1">
            <thead>
                <tr>
                    <th>Materia</th>
                    <th>Categoría</th>
                    <th>Nota</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($nota = $notas->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $nota['materia']; ?></td>
                        <td><?php echo $nota['categoria']; ?></td>
                        <td><?php echo $nota['nota']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

