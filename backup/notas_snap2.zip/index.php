<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] != 'estudiante') {
    die("Acceso denegado. Debes ser estudiante para entrar.");
}


$usuario_id = $_SESSION['usuario_id'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Profesores</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="navbar">
        <div class="logo">Sistema Escolar</div>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="notas.php">Asignar Notas</a></li>
                <li><a href="logout.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <h1>Bienvenido al Panel de Profesores</h1>
        <p>¡Hola! Aquí puedes gestionar tus cursos, materias y asignar notas a los estudiantes.</p>
        <div class="card-container">
            <div class="card">
                <h2>Cursos</h2>
                <p>Gestiona los cursos que enseñas y organiza tus materias.</p>
                <a href="cursos.php" class="btn">Ver Cursos</a>
            </div>
            <div class="card">
                <h2>Notas</h2>
                <p>Asigna y revisa las notas de tus estudiantes.</p>
                <a href="notas.php" class="btn">Gestionar Notas</a>
            </div>
            <div class="card">
                <h2>Perfil</h2>
                <p>Actualiza tu información personal y preferencias.</p>
                <a href="perfil.php" class="btn">Editar Perfil</a>
            </div>
        </div>
    </main>

    <footer>
        <p>© 2024 Sistema Escolar. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
