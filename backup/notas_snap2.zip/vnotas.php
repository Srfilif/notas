<?php
session_start();
include 'database.php';

// Verificar si el usuario está logueado y es un estudiante
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: login.php");
    exit;
}

// Obtener el ID de la materia seleccionada (si lo hay)
$materia_id = isset($_GET['materia_id']) ? intval($_GET['materia_id']) : null;

// Obtener las materias del estudiante
$usuario_id = $_SESSION['usuario_id'];
$materias = $conn->query("SELECT DISTINCT m.id, m.nombre
                          FROM materias m
                          JOIN notas n ON m.id = n.materia_id
                          WHERE n.estudiante_id = $usuario_id");

// Filtrar las notas y categorías según la materia seleccionada
$notas_query = "SELECT n.nota, m.nombre AS materia, c.nombre AS categoria, m.id AS materia_id
                FROM notas n
                JOIN materias m ON n.materia_id = m.id
                JOIN categorias_notas c ON n.categoria_id = c.id
                WHERE n.estudiante_id = $usuario_id";

$categorias_query = "SELECT c.nombre AS categoria, m.nombre AS materia, m.id AS materia_id
                     FROM categorias_notas c
                     JOIN materias m ON c.materia_id = m.id";

if ($materia_id) {
    $notas_query .= " AND m.id = $materia_id";
    $categorias_query .= " WHERE m.id = $materia_id";
}

$notas = $conn->query($notas_query);
$categorias = $conn->query($categorias_query);

// Agrupar notas y categorías por materia
$materias_notas = [];
while ($nota = $notas->fetch_assoc()) {
    $materias_notas[$nota['materia']][] = $nota;
}

$materias_categorias = [];
while ($categoria = $categorias->fetch_assoc()) {
    $materias_categorias[$categoria['materia']][] = $categoria['categoria'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Notas</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f7f9fc;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table thead th {
            background-color: #0056b3;
            color: white;
            padding: 10px;
            text-align: center;
        }
        table tbody td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        .subject-header {
            background-color: #f0f8ff;
            text-align: center;
            font-weight: bold;
            font-size: 16px;
        }
        select {
            padding: 5px;
            font-size: 16px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Mis Notas</h1>

        <!-- Formulario para seleccionar la materia -->
        <form method="GET" action="">
            <label for="materia">Seleccionar Materia:</label>
            <select name="materia_id" id="materia" onchange="this.form.submit()">
                <option value="">-- Ver Todas --</option>
                <?php while ($materia = $materias->fetch_assoc()): ?>
                    <option value="<?php echo $materia['id']; ?>" <?php echo $materia_id == $materia['id'] ? 'selected' : ''; ?>>
                        <?php echo $materia['nombre']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>

        <!-- Mostrar las tablas de notas -->
        <?php foreach ($materias_notas as $materia_nombre => $notas_materia): ?>
            <table>
                <thead>
                    <tr>
                        <th colspan="<?php echo count($materias_categorias[$materia_nombre]) + 1; ?>" class="subject-header">
                            <?php echo strtoupper($materia_nombre); ?>
                        </th>
                    </tr>
                    <tr>
                        <th>ASIGNATURA</th>
                        <?php foreach ($materias_categorias[$materia_nombre] as $categoria): ?>
                            <th><?php echo $categoria; ?></th>
                        <?php endforeach; ?>
                        <th>PROMEDIO</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $materia_nombre; ?></td>
                        <?php 
                        $suma_notas = 0;
                        $cantidad_notas = 0;
                        foreach ($materias_categorias[$materia_nombre] as $categoria): ?>
                            <td>
                                <?php
                                $nota_en_categoria = '';
                                foreach ($notas_materia as $nota) {
                                    if ($nota['categoria'] === $categoria) {
                                        $nota_en_categoria = $nota['nota'];
                                        $suma_notas += $nota['nota'];
                                        $cantidad_notas++;
                                        break;
                                    }
                                }
                                echo $nota_en_categoria ? $nota_en_categoria : '-';
                                ?>
                            </td>
                        <?php endforeach; ?>
                        <td>
                            <?php echo $cantidad_notas > 0 ? number_format($suma_notas / $cantidad_notas, 2) : '-'; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endforeach; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
