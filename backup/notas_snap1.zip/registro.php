<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_BCRYPT);
    $rol_id = $_POST['rol'];

    // Verificar que el email no exista
    $query = $conn->query("SELECT id FROM usuarios WHERE email = '$email'");
    if ($query->num_rows > 0) {
        echo "El correo ya está registrado.";
    } else {
        // Insertar usuario
        $conn->query("INSERT INTO usuarios (nombre, email, contraseña, rol_id) VALUES ('$nombre', '$email', '$contraseña', $rol_id)");
        echo "Registro exitoso. <a href='login.php'>Iniciar sesión</a>";
    }
}
?>

<form method="POST">
    <label>Nombre:</label>
    <input type="text" name="nombre" required>
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Contraseña:</label>
    <input type="password" name="contraseña" required>
    <label>Rol:</label>
    <select name="rol" required>
        <option value="1">Administrador</option>
        <option value="2">Profesor</option>
        <option value="3">Estudiante</option>
    </select>
    <button type="submit">Registrarse</button>
</form>
