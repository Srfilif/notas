<?php
session_start();
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $contraseña = $_POST['contraseña'];

    $query = $conn->query("SELECT * FROM usuarios WHERE email = '$email'");
    $usuario = $query->fetch_assoc();

    if ($usuario && password_verify($contraseña, $usuario['contraseña'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['rol_id'] = $usuario['rol_id'];
        
        header('Location: index.php');
        exit();
    } else {
        echo "Credenciales incorrectas.";
    }
}
?>

<form method="POST">
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Contraseña:</label>
    <input type="password" name="contraseña" required>
    <button type="submit">Iniciar sesión</button>
</form>
